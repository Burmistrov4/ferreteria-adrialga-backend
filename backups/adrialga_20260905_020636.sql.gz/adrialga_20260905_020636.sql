-- MySQL dump 10.13  Distrib 8.0.46, for Win64 (x86_64)
--
-- Host: altaria.proxy.rlwy.net    Database: railway
-- ------------------------------------------------------
-- Server version	9.4.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `categorias`
--

DROP TABLE IF EXISTS `categorias`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categorias` (
  `Categoria_ID` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Descripcion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT '1',
  `Fecha_Registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Categoria_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `categorias`
--

LOCK TABLES `categorias` WRITE;
/*!40000 ALTER TABLE `categorias` DISABLE KEYS */;
INSERT INTO `categorias` VALUES (1,'Medidores','',1,'2026-08-31 07:14:30'),(2,'Impermeabilizante','',1,'2026-09-01 23:36:24'),(3,'Electricidad','Cables, cajetines, tubos, interruptores, tomacorrientes, tableros, Breakers.',1,'2026-09-02 00:18:47'),(4,'Herramientas','Esmeriles, taladros, destornilladores, alicates, llaves, martillos, tenazas, seguetas, serruchos.',1,'2026-09-02 00:29:08'),(5,'Iluminacion','Bombillos, lamparas, tiras led.',1,'2026-09-02 00:30:34'),(6,'Construccion','Bloques, tabelones, cemento, ladrillos, arena, piedra.',1,'2026-09-02 00:34:45'),(7,'Pinturas','Pintura aerosol, esmaltes, caucho, fondo, brochas, rodillos, bandejas.',1,'2026-09-02 00:37:19');
/*!40000 ALTER TABLE `categorias` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `clientes` (
  `Cliente_ID` int NOT NULL AUTO_INCREMENT,
  `RIF_Cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Razon_Social` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Fecha_Registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Num_Documento` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `Tipo_Documento` varchar(1) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'V',
  PRIMARY KEY (`Cliente_ID`),
  UNIQUE KEY `RIF_Cedula` (`RIF_Cedula`),
  KEY `IDX_Clientes_NumDocumento` (`Num_Documento`),
  KEY `IDX_Clientes_RazonSocial` (`Razon_Social`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'V-00000000','Consumidor Final','Cliente de mostrador','0000000000','consumidor@adrialga.local','2026-08-29 10:10:18','','V'),(2,'V-14383540','Frida Thais','Flor Amarillo Conj Resd El Alboral','04124661379','trow-burmis@gmail.com','2026-08-31 06:29:17','','V'),(3,'V-28036972','Lorenzo Roca','Flor Amarillo Conj Resd El Alboral','0412-4661379',NULL,'2026-09-01 23:34:24','28036972','V'),(4,'V-12315692','Jose Tarazon','valencia','04121402676',NULL,'2026-09-02 00:01:12','12315692','V'),(5,'V-15333632','Ana Guerra','Valencia','04121793253',NULL,'2026-09-02 00:45:10','15333632','V');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_facturas`
--

DROP TABLE IF EXISTS `detalle_facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_facturas` (
  `Detalle_ID` int NOT NULL AUTO_INCREMENT,
  `Factura_ID` int NOT NULL,
  `Producto_ID` int NOT NULL,
  `Cantidad` int NOT NULL,
  `Precio_Unitario` decimal(10,2) NOT NULL DEFAULT '0.00',
  `Costo_Unitario_Historico` decimal(18,2) NOT NULL DEFAULT '0.00',
  `Subtotal` decimal(12,2) DEFAULT NULL,
  PRIMARY KEY (`Detalle_ID`),
  KEY `FK_DetalleFactura_Facturas` (`Factura_ID`),
  KEY `IDX_DetalleFacturas_Producto` (`Producto_ID`),
  CONSTRAINT `FK_DetalleFactura_Facturas` FOREIGN KEY (`Factura_ID`) REFERENCES `facturas` (`Factura_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DetalleFactura_Productos` FOREIGN KEY (`Producto_ID`) REFERENCES `productos` (`Producto_ID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_facturas`
--

LOCK TABLES `detalle_facturas` WRITE;
/*!40000 ALTER TABLE `detalle_facturas` DISABLE KEYS */;
INSERT INTO `detalle_facturas` VALUES (1,1,1,1,8.00,0.00,8.00),(2,2,2,1,50.00,0.00,50.00),(3,3,2,1,50.00,0.00,50.00),(4,4,1,1,8.00,7.00,8.00),(5,5,4,16,8.00,4.50,128.00);
/*!40000 ALTER TABLE `detalle_facturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalle_notas_entrega`
--

DROP TABLE IF EXISTS `detalle_notas_entrega`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `detalle_notas_entrega` (
  `Detalle_Nota_ID` int NOT NULL AUTO_INCREMENT,
  `Nota_ID` int NOT NULL,
  `Producto_ID` int NOT NULL,
  `Cantidad` int NOT NULL,
  `Costo_Unitario` decimal(18,2) NOT NULL DEFAULT '0.00',
  `Subtotal_Costo` decimal(18,2) DEFAULT NULL,
  PRIMARY KEY (`Detalle_Nota_ID`),
  KEY `FK_DetalleNota_Cabecera` (`Nota_ID`),
  KEY `IDX_DetalleNotas_Producto` (`Producto_ID`),
  CONSTRAINT `FK_DetalleNota_Cabecera` FOREIGN KEY (`Nota_ID`) REFERENCES `notas_entrega_entrada` (`Nota_ID`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `FK_DetalleNota_Productos` FOREIGN KEY (`Producto_ID`) REFERENCES `productos` (`Producto_ID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalle_notas_entrega`
--

LOCK TABLES `detalle_notas_entrega` WRITE;
/*!40000 ALTER TABLE `detalle_notas_entrega` DISABLE KEYS */;
INSERT INTO `detalle_notas_entrega` VALUES (1,1,1,15,7.00,105.00),(2,2,2,10,40.00,400.00);
/*!40000 ALTER TABLE `detalle_notas_entrega` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturas`
--

DROP TABLE IF EXISTS `facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `facturas` (
  `Factura_ID` int NOT NULL AUTO_INCREMENT,
  `Numero_Control` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Fecha_Emision` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Subtotal` decimal(12,2) NOT NULL DEFAULT '0.00',
  `Total_IVA` decimal(12,2) NOT NULL DEFAULT '0.00',
  `Total_General` decimal(12,2) DEFAULT NULL,
  `Estatus` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Completada',
  `Cliente_ID` int NOT NULL,
  `Usuario_ID` int NOT NULL,
  `Tasa_Cambio` decimal(18,4) DEFAULT NULL,
  PRIMARY KEY (`Factura_ID`),
  UNIQUE KEY `Numero_Control` (`Numero_Control`),
  KEY `FK_Facturas_Clientes` (`Cliente_ID`),
  KEY `FK_Facturas_Usuarios` (`Usuario_ID`),
  KEY `IDX_Facturas_Fecha` (`Fecha_Emision`),
  CONSTRAINT `FK_Facturas_Clientes` FOREIGN KEY (`Cliente_ID`) REFERENCES `clientes` (`Cliente_ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `FK_Facturas_Usuarios` FOREIGN KEY (`Usuario_ID`) REFERENCES `usuarios` (`Usuario_ID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturas`
--

LOCK TABLES `facturas` WRITE;
/*!40000 ALTER TABLE `facturas` DISABLE KEYS */;
INSERT INTO `facturas` VALUES (1,'FV-20260831072905','2026-08-31 07:29:06',8.00,1.28,9.28,'Pagada',2,1,NULL),(2,'FV-20260901234146','2026-09-01 23:41:46',50.00,8.00,58.00,'Pagada',1,1,801.1752),(3,'FV-20260902000447','2026-09-02 00:04:47',50.00,8.00,58.00,'Pagada',4,1,801.1752),(4,'FV-20260902000736','2026-09-02 00:07:37',8.00,1.28,9.28,'Pagada',4,1,801.1752),(5,'FV-20260902004705','2026-09-02 00:47:05',128.00,20.48,148.48,'Pagada',5,1,801.1752);
/*!40000 ALTER TABLE `facturas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notas_entrega_entrada`
--

DROP TABLE IF EXISTS `notas_entrega_entrada`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notas_entrega_entrada` (
  `Nota_ID` int NOT NULL AUTO_INCREMENT,
  `Numero_Nota` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Fecha_Recepcion` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Total_Costo` decimal(18,2) NOT NULL DEFAULT '0.00',
  `Estatus` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Procesada',
  `Proveedor_ID` int NOT NULL,
  `Usuario_ID` int NOT NULL,
  PRIMARY KEY (`Nota_ID`),
  UNIQUE KEY `Numero_Nota` (`Numero_Nota`),
  KEY `FK_Notas_Proveedores` (`Proveedor_ID`),
  KEY `FK_Notas_Usuarios` (`Usuario_ID`),
  KEY `IDX_Notas_Fecha` (`Fecha_Recepcion`),
  CONSTRAINT `FK_Notas_Proveedores` FOREIGN KEY (`Proveedor_ID`) REFERENCES `proveedores` (`Proveedor_ID`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `FK_Notas_Usuarios` FOREIGN KEY (`Usuario_ID`) REFERENCES `usuarios` (`Usuario_ID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notas_entrega_entrada`
--

LOCK TABLES `notas_entrega_entrada` WRITE;
/*!40000 ALTER TABLE `notas_entrega_entrada` DISABLE KEYS */;
INSERT INTO `notas_entrega_entrada` VALUES (1,'NE-20260901193134','2026-09-01 23:31:35',105.00,'Procesada',1,1),(2,'NE-20260901200831','2026-09-02 00:08:31',400.00,'Procesada',1,1);
/*!40000 ALTER TABLE `notas_entrega_entrada` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pagos`
--

DROP TABLE IF EXISTS `pagos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pagos` (
  `Pago_ID` int NOT NULL AUTO_INCREMENT,
  `Factura_ID` int NOT NULL,
  `Metodo_Pago` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Monto` decimal(12,2) NOT NULL,
  `Referencia` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Fecha_Pago` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `Tasa_Cambio` decimal(18,4) DEFAULT NULL,
  PRIMARY KEY (`Pago_ID`),
  KEY `FK_Pagos_Facturas` (`Factura_ID`),
  CONSTRAINT `FK_Pagos_Facturas` FOREIGN KEY (`Factura_ID`) REFERENCES `facturas` (`Factura_ID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pagos`
--

LOCK TABLES `pagos` WRITE;
/*!40000 ALTER TABLE `pagos` DISABLE KEYS */;
INSERT INTO `pagos` VALUES (1,2,'Efectivo USD',30.00,'','2026-09-01 23:41:46',801.1752),(2,2,'Pago Móvil',12432.91,'','2026-09-01 23:41:46',801.1752),(3,2,'Punto de Venta',10000.00,'','2026-09-01 23:41:46',801.1752),(4,3,'Efectivo VES',46468.16,'0001283564','2026-09-02 00:04:47',801.1752),(5,3,'Punto de Venta',46468.16,'0001283564','2026-09-02 00:04:47',801.1752),(6,4,'Efectivo USD',9.28,'','2026-09-02 00:07:37',801.1752),(7,5,'Punto de Venta',118958.49,'53692840','2026-09-02 00:47:05',801.1752);
/*!40000 ALTER TABLE `pagos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productos`
--

DROP TABLE IF EXISTS `productos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productos` (
  `Producto_ID` int NOT NULL AUTO_INCREMENT,
  `SKU_Codigo` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Nombre` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Precio_Venta` decimal(18,2) NOT NULL DEFAULT '0.00',
  `Costo_Promedio` decimal(18,2) NOT NULL DEFAULT '0.00',
  `Stock_Actual` int NOT NULL DEFAULT '0',
  `Stock_Minimo` int NOT NULL DEFAULT '5',
  `Categoria_ID` int NOT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT '1',
  `Fecha_Registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Producto_ID`),
  UNIQUE KEY `SKU_Codigo` (`SKU_Codigo`),
  KEY `IDX_Productos_Categoria` (`Categoria_ID`),
  CONSTRAINT `FK_Productos_Categorias` FOREIGN KEY (`Categoria_ID`) REFERENCES `categorias` (`Categoria_ID`) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productos`
--

LOCK TABLES `productos` WRITE;
/*!40000 ALTER TABLE `productos` DISABLE KEYS */;
INSERT INTO `productos` VALUES (1,'002','Flexometro',8.00,7.00,33,5,1,1,'2026-08-31 07:17:52'),(2,'IMP-001','Manto',58.00,22.22,18,3,2,1,'2026-09-01 23:38:38'),(3,'Elec-003','Interruptor empotrar sencillo',7.00,3.50,30,5,3,1,'2026-09-02 00:22:59'),(4,'Toma-004','Tomacorriente doble',8.00,4.50,4,5,3,1,'2026-09-02 00:42:18');
/*!40000 ALTER TABLE `productos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedores`
--

DROP TABLE IF EXISTS `proveedores`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proveedores` (
  `Proveedor_ID` int NOT NULL AUTO_INCREMENT,
  `RIF_Cedula` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Razon_Social` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telefono` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Direccion` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `Activo` tinyint(1) NOT NULL DEFAULT '1',
  `Fecha_Registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Proveedor_ID`),
  UNIQUE KEY `RIF_Cedula` (`RIF_Cedula`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedores`
--

LOCK TABLES `proveedores` WRITE;
/*!40000 ALTER TABLE `proveedores` DISABLE KEYS */;
INSERT INTO `proveedores` VALUES (1,'J-30974689-8','Ferrocerámica Valcro C.A.','412-2984603',NULL,'Carretera Valencia - Güigüe, Sector Flor Amarillo',1,'2026-08-31 07:35:31');
/*!40000 ALTER TABLE `proveedores` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usuarios` (
  `Usuario_ID` int NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Credencial` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Rol` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Cajero',
  `Activo` tinyint(1) NOT NULL DEFAULT '1',
  `Fecha_Registro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`Usuario_ID`),
  UNIQUE KEY `Credencial` (`Credencial`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (1,'Administrador del Sistema','admin','$2a$10$/bl3GxeG3/LdO2dPY5QNKOECAN9Sht1mk9VuQpR/6IcEbHwNXpZA2','ADMIN',1,'2026-08-29 10:10:17');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'railway'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-09-05  2:07:15
